package com.project;

import java.util.Scanner;

public class DebitService {
	
	//체크카드 내용 출력 
	public static void debitList() {
			
		Data.debitlist.clear();
		Data.loadDebit();
		Scanner scan = new Scanner(System.in);

		boolean loop = true;
		boolean manager =true;
		for(Debit d : Data.debitlist) {
			System.out.println();
			System.out.printf("%s. %s\r",d.getNo(),d.getCardname());
			System.out.printf("혜택: %s\r",d.getBenefit());
			System.out.println();
		}
		UI.backSapce();
		System.out.print("숫자 입력: ");
		String input2 =scan.nextLine();
		while(loop) {
			if("30".compareTo(input2)>=0) {
				loop=false;
			}
			else {
				System.out.println("목록의 숫자를 입력해주세요.");
				System.out.print("숫자 입력: ");//상세정보를 받을 번호 입력
				input2 = scan.nextLine();
				
			}
		}
		if(input2.equals("0")) {
			CardService.cardMain();
		}else {
			Data.loadDebitD(input2);
			debitD(input2);
			UI.backSapce();
			Data.debit_d.clear();
			System.out.print("숫자입력: ");
			String input3 =scan.nextLine();
			if(input3.equals("0")) {
				debitList();
			}else {
				System.out.println("올바른 숫자를 입력하세요.");
			}
		}
	}
	
	//상세내용 개별 출력
	public static void debitD(String input) {
		
		for(Debit d : Data.debitlist) {
			if(d.getNo().equals(input)) {
				for(Debit dd : Data.debit_d) {
					System.out.printf("%s\r",dd.getdBenefit());	
				
				}
				break;
			}
		}
	}
}
