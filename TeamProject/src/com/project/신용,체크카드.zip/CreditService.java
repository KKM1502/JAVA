package com.project;

import java.util.Scanner;

public class CreditService {
	
	public static void creditList() {

		Scanner scan = new Scanner(System.in);
		boolean loop =true;
		for(Credit c : Data.creditlist) {
			System.out.println();
			System.out.printf("%s. %s\r",c.getNo(),c.getCardName());
			System.out.printf("혜택: %s\r",c.getBenefit());
			System.out.println();
			
		}
		UI.backSapce();
		
	
		System.out.print("숫자 입력: ");//상세정보를 받을 번호 입력
		String input2 = scan.nextLine();
		
		while(loop) {
			if("30".compareTo(input2)>=0) {
				loop=false;
			}
			else {
				System.out.println("목록의 숫자를 입력해주세요.");
				System.out.print("숫자 입력: ");//상세정보를 받을 번호 입력
				input2 = scan.nextLine();
				
			}
		}
		if(input2.equals("0")) {
			CardService.cardMain();
		}

			
			Data.loadCreditD(input2);//input2에 대한 상세정보 가져오기
			creditD(input2);
			Data.credit_d.clear();
			UI.backSapce();
			
			System.out.print("숫자입력: ");
			String input3 =scan.nextLine();
			if(input3.equals("0")) {
				creditList();
			}else {
				System.out.println("올바른 숫자를 입력하세요.");
			}
		}

	
	public static void creditD(String input) {
		System.out.print("---------------------------------------------상세 보기--------------------------------------------\r");
		
		for(Credit c : Data.creditlist) {
			if(c.getNo().equals(input)) {
				System.out.printf("%s. %s\r",c.getNo(),c.getCardName());
				System.out.printf("연회비:%s\r전월실적:%s\r혜택:%s\r\r상세혜택\r",c.getAnnual(),c.getPre(),c.getBenefit());
				
				for(Credit cd : Data.credit_d) {
				
					System.out.printf("%s\r",cd.getdBenefit());	
				
				}
			break;
			}
		}
		System.out.print("--------------------------------------------------------------------------------------------------\r");
		
	}
	public static void userSelect(String[] input) {
		for (int i = 0; i < input.length; i++) {
			System.out.printf("%d.%s\r",i,input[i]);
		}
		
	}

}
