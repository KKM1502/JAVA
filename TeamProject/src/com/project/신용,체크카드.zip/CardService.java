package com.project;

import java.util.Scanner;

public class CardService {
	
	public static void cardMain() {
		Data.creditlist.clear();  //refresh
		Data.loadCredit();
		Data.debitlist.clear();
		Data.loadDebit();
		Scanner scan = new Scanner(System.in);
		
		UI.cardMain(); //카드 정보/조회 화면 호출
		System.out.print("숫자를 입력해주세요.: ");
		String input = scan.nextLine();
		if(input.equals("1")) {
			UI.subMenu("카드 목록");
			DebitService.debitList();
		}
		else if(input.equals("2")) {
			UI.subMenu("카드 목록");
			CreditService.creditList();

		}else if(input.equals("3")) {
			UI.subMenu("카드 추천");
			cardRecommend();
		}else if(input.equals("4")) {
			Main.main(null);
		}else {
			System.out.println("올바른 숫자를 입력해주세요");
		}
	}
	public static void cardRecommend() {
		Scanner scan = new Scanner(System.in);
		System.out.print("추천받을 카드 종류 입력"
				+ "\r1.체크카드"
				+ "\r2.신용카드\r");
		System.out.print("추천받을 카드 선택(숫자): ");
		String input = scan.nextLine();
		
		UI.subMenu("사용처");
		System.out.print("1.교통\t\t\t2.주유\t\t\t3.통신\t\t\t4.마트/편의점\t\t\t5.쇼핑\t\t\t6.푸드\r"
				+ "7.카페/디저트\t\t8.디지털구독\t\t9.뷰티/피트니스\t\t10.공과금/렌탈\t\t\t11.병원/약국\t\t12.애완동물\r"
				+ "13.교육/육아\t\t14.자동차/하이패스\t15.레저/스포츠\t\t16.영화/문화\t\t\t17.간편결제\t\t18.항공마일리지\r"
				+ "19.공황라운지/PP\t\t20.프리미엄\t\t21.제휴/PLCC\t\t22.여행/숙박\t\t\t23.해외\t\t\t24.비즈니스\r");
		System.out.print("숫자 입력(중복선택): ");
		String input2 = scan.nextLine();
		
		if(input.equals("1")&&input2.contains("24")) {
			
		}

	}
	
	
	
	
	
	
//	
//	public static void inputVerify(String a, String input){
//		boolean loop = true;
//		Scanner scan = new Scanner(System.in);
//		while(loop) {
//			if(a.compareTo(input)>=0) {
//				loop=false;
//			}
//			else {
//				System.out.println("올바른 숫자를 입력해주세요.");
//				System.out.print("숫자 입력: ");//상세정보를 받을 번호 입력
//				input = scan.nextLine();
//				
//			}
//		}
//	}
}
